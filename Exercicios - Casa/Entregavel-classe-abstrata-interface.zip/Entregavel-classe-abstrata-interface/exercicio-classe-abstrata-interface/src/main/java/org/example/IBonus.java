package org.example;

public interface IBonus {
    public Double getValorBonus();
}
