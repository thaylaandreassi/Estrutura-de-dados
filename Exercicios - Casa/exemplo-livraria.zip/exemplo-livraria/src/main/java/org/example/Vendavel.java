package org.example;

public interface Vendavel {

    public Double getValorVenda();
}
