package org.example;
public class Banco {

    // Atributos
    PilhaObj<Operacao> pilhaOperacao = new PilhaObj(10);
    FilaObj<Operacao> filaOperacao = new FilaObj(10);
    // Contador de operações empilhadas
    Integer contadorOperacao = 0;

    // Métodos

    /* Método debitar - recebe o valor a ser debitado e o objeto conta bancária
       Se o débito ocorreu com sucesso, cria um objeto Operacao com os valores adequados
       e empilha a operação para poder ser desfeita. Atualiza contadorOperacao.
     */
    public void debitar(Double valor, ContaBancaria conta) {

        if (conta == null) {
            throw new IllegalArgumentException("Conta inválida");
        }

        if (valor <= 0) {
            throw new IllegalArgumentException("Valor inválido");
        }

        boolean debitoRealizado = conta.debitar(valor);
        if (debitoRealizado) {
            Operacao operacao = new Operacao(conta, "Débito", valor);

            pilhaOperacao.push(operacao);

            contadorOperacao++;
        }
    }


    /* Método creditar - recebe o valor a ser depositado e o objeto conta bancária
       Executa o depósito, cria um objeto Operacao com os valores adequados
       e empilha a operação para poder ser desfeita. Atualiza contadorOperacao.
     */
    public void creditar(Double valor, ContaBancaria conta) {
        if (valor <= 0) {
            throw new IllegalArgumentException("Valor inválido");
        }
        if (conta == null) {
            throw new IllegalArgumentException("Conta inválida");
        }

        Double novoSaldo = conta.getSaldo() + valor;
        conta.setSaldo(novoSaldo);
        Operacao operacao = new Operacao(conta, "Depósito", valor);
        pilhaOperacao.push(operacao);
        contadorOperacao++;
    }


    /* Método desfazerOperacao - recebe a quantidade de operações a serem desfeitas
       Se essa quantidade for inválida, lança IllegalArgumentException
       Senão, "desfaz" a quantidade de operações passadas como argumento
       e atualiza o contadorOperacao
     */
    public void desfazerOperacao(Integer qtdOperacaoDesfeita) {
        if (qtdOperacaoDesfeita <= 0 || qtdOperacaoDesfeita > contadorOperacao) {
            throw new IllegalArgumentException("Quantidade de operações inválida");
        }

        for (int i = 0; i < qtdOperacaoDesfeita; i++) {
            Operacao operacaoDesfeita = pilhaOperacao.pop();

            if (operacaoDesfeita.getTipoOperacao().equals("Débito")) {
                ContaBancaria contaBancaria = operacaoDesfeita.getContaBancaria();
                double valorOperacao = operacaoDesfeita.getValor();
                contaBancaria.creditar(valorOperacao);
            } else if (operacaoDesfeita.getTipoOperacao().equals("Depósito")) {
                ContaBancaria contaBancaria = operacaoDesfeita.getContaBancaria();
                double valorOperacao = operacaoDesfeita.getValor();
                contaBancaria.debitar(valorOperacao);
            }

            contadorOperacao--;
        }
    }



    /* Método agendarOperacao - recebe o tipo da operaçõa, o valor e o objeto conta bancária
       Se um dos argumentos for inválido, lança IllegalArgumentException.
       Senão, cria um objeto Operacao e insere esse objeto na fila.
    */
    public void agendarOperacao(String tipoOperacao, Double valor, ContaBancaria conta) {
        // Verifica se os argumentos são válidos
        if (tipoOperacao == null || tipoOperacao.isEmpty() || valor == null || conta == null || tipoOperacao != "Débito") {
            throw new IllegalArgumentException("Argumentos inválidos");
        }

        if (valor <= 0) {
            throw new IllegalArgumentException("Valor inválido");
        }

        // Cria a operação e insere na fila
        Operacao operacao = new Operacao(conta, tipoOperacao, valor);
        ++contadorOperacao;
        filaOperacao.insert(operacao);
    }

    /* Método executarOperacoesAgendadas
       Se não houver operações na fila, exibe mensagem de que não há operações agendadas.
       Senão, esvazia a fila, executando cada uma das operações agendadas.
    */
    public void executarOperacoesAgendadas() {
        if (filaOperacao.isEmpty()) {
            System.out.println("Não há operações agendadas.");
        } else {
            while (!filaOperacao.isEmpty()) {
                Operacao operacao = filaOperacao.poll();
                if (operacao.getTipoOperacao().equals("credito")) {
                    operacao.getContaBancaria().creditar(operacao.getValor());
                } else if (operacao.getTipoOperacao().equals("debito")) {
                    operacao.getContaBancaria().debitar(operacao.getValor());
                }
            }
        }
    }


    // Gettens
    public PilhaObj<Operacao> getPilhaOperacao() {
        return pilhaOperacao;
    }

    public FilaObj<Operacao> getFilaOperacao() {
        return filaOperacao;
    }

    public Integer getContadorOperacao() {
        return contadorOperacao;
    }
}