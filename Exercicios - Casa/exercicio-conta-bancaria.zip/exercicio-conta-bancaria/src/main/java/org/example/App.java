package org.example;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {

        PilhaObj<Operacao> pilhaOperacoes = new PilhaObj<>(10);
        FilaObj<Operacao> filaOperacoes = new FilaObj<>(10);
        int contadorOperacoes = 0;

        ContaBancaria conta1 = new ContaBancaria(1, 900.0);
        ContaBancaria conta2 = new ContaBancaria(2, 1000.0);

        Scanner leitor = new Scanner(System.in);
        int opcao = 0;

        while (opcao != 6) {
            System.out.println("1- Debitar valor");
            System.out.println("2- Creditar (Depositar) valor");
            System.out.println("3- Desfazer operação");
            System.out.println("4- Agendar operação");
            System.out.println("5- Executar operações agendadas");
            System.out.println("6- Sair");
            opcao = leitor.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Digite o número da conta: ");
                    int numeroContaDebito = leitor.nextInt();
                    System.out.print("Digite o valor a ser debitado: ");
                    double valorDebito = leitor.nextDouble();

                    ContaBancaria contaDebito = null;
                    if (numeroContaDebito == conta1.getNumero()) {
                        contaDebito = conta1;
                    } else if (numeroContaDebito == conta2.getNumero()) {
                        contaDebito = conta2;
                    }

                    if (contaDebito != null) {
                        if (contaDebito.debitar(valorDebito)) {
                            Operacao operacaoDebito = new Operacao(contaDebito, "debito", valorDebito);
                            try {
                                pilhaOperacoes.push(operacaoDebito);
                                contadorOperacoes++;
                                System.out.println("Operação de débito realizada.");
                            } catch (IllegalStateException e) {
                                System.out.println("Erro ao empilhar operação: " + e.getMessage());
                            }
                        }
                    } else {
                        System.out.println("Conta não encontrada.");
                    }
                    break;

                case 2:
                    System.out.print("Digite o número da conta: ");
                    int numeroContaCredito = leitor.nextInt();
                    System.out.print("Digite o valor a ser creditado: ");
                    double valorCredito = leitor.nextDouble();

                    ContaBancaria contaCredito = null;
                    if (numeroContaCredito == conta1.getNumero()) {
                        contaCredito = conta1;
                    } else if (numeroContaCredito == conta2.getNumero()) {
                        contaCredito = conta2;
                    }

                    if (contaCredito != null) {
                        contaCredito.creditar(valorCredito);
                        Operacao operacaoCredito = new Operacao(contaCredito, "credito", valorCredito);
                        try {
                            pilhaOperacoes.push(operacaoCredito);
                            contadorOperacoes++;
                            System.out.println("Operação de crédito realizada.");
                        } catch (IllegalStateException e) {
                            System.out.println("Erro ao empilhar operação: " + e.getMessage());
                        }
                    } else {
                        System.out.println("Conta não encontrada.");

                    }
                    // Desfazer operação
                case 3:
                    System.out.println("Digite a quantidade de operações a serem desfeitas:");
                    int quantidade = leitor.nextInt();
                    if (quantidade > contadorOperacoes) {
                        System.out.println("Quantidade inválida!");
                    } else {
                        for (int i = 0; i < quantidade; i++) {
                            try {
                                Operacao operacao = pilhaOperacoes.pop();
                                ContaBancaria conta = operacao.getContaBancaria();
                                double valor = operacao.getValor();
                                if (operacao.getTipoOperacao().equals("credito")) {
                                    conta.debitar(valor);
                                    System.out.println("Operação de crédito desfeita!");
                                } else {
                                    conta.creditar(valor);
                                    System.out.println("Operação de débito desfeita!");
                                }
                                contadorOperacoes--;
                            } catch (IllegalStateException e) {
                                System.out.println("Erro: " + e.getMessage());
                            }
                        }
                    }
                    break;
                case 4:
                    System.out.print("Digite o tipo de operação (debito/credito): ");
                    String tipoOperacao = leitor.next();
                    System.out.print("Digite o número da conta: ");
                    int numeroContaAgendar = leitor.nextInt();
                    System.out.print("Digite o valor da operação: ");
                    double valorOperacao = leitor.nextDouble();

                    ContaBancaria contaAgendar = null;
                    if (numeroContaAgendar == conta1.getNumero()) {
                        contaAgendar = conta1;
                    } else if (numeroContaAgendar == conta2.getNumero()) {
                        contaAgendar = conta2;
                    }

                    if (contaAgendar != null) {
                        Operacao operacaoAgendar = new Operacao(contaAgendar, tipoOperacao, valorOperacao);
                        try {
                            filaOperacoes.insert(operacaoAgendar);
                            System.out.println("Operação agendada com sucesso.");
                        } catch (IllegalStateException e) {
                            System.out.println("Erro ao enfileirar operação: " + e.getMessage());
                        }
                    } else {
                        System.out.println("Conta não encontrada.");
                    }
                    break;
                    // Verifica se a fila de operações agendadas está vazia
                case 5:
                    if (filaOperacoes.isEmpty()) {
                        System.out.println("Não há operações agendadas.");
                    } else {
                        // Executa cada uma das operações agendadas
                        while (!filaOperacoes.isEmpty()) {
                            Operacao operacao = filaOperacoes.poll();
                            try {
                                // Executa a operação de acordo com o tipo
                                if (operacao.getTipoOperacao().equals("credito")) {
                                    operacao.getContaBancaria().creditar(operacao.getValor());
                                } else if (operacao.getTipoOperacao().equals("debito")) {
                                    operacao.getContaBancaria().debitar(operacao.getValor());
                                }
                                System.out.println("Operação executada: " + operacao.toString());
                            } catch (Exception e) {
                                System.out.println("Saldo insuficiente na conta " + operacao.getContaBancaria().getNumero() + ".");
                            }
                        }
                    }
                    break;
                case 6:
                    System.out.println("FIM");
                    break;


            }
        }
    }
}
