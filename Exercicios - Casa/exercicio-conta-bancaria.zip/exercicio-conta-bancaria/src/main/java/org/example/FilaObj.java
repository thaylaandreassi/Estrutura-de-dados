package org.example;

public class FilaObj<T> {
    private T[] fila;
    private int capacidade;
    private int tamanho;

    public FilaObj(int capacidade) {
        this.capacidade = capacidade;
        fila = (T[]) new Object[capacidade];
        this.tamanho = 0;
    }

    public boolean isEmpty() {
        return tamanho == 0;
    }

    public boolean isFull() {
        return tamanho == capacidade;
    }

    public void insert(T elemento) {
        if (!isFull()) {
            fila[tamanho] = elemento;
            tamanho++;
        } else {
            throw new IllegalStateException("Fila cheia!");
        }
    }

    public T peek() {
        if (!isEmpty()) {
            return fila[0];
        } else {
            throw new IllegalStateException("Fila vazia!");
        }
    }

    public T poll() {
        if (!isEmpty()) {
            T elemento = fila[0];
            for (int i = 0; i < tamanho - 1; i++) {
                fila[i] = fila[i + 1];
            }
            tamanho--;
            return elemento;
        } else {
            throw new IllegalStateException("Fila vazia!");
        }
    }

    public void exibe() {
        if (isEmpty()) {
            System.out.println("Fila vazia!");
        } else {
            for (int i = 0; i < tamanho; i++) {
                System.out.print(fila[i] + " ");
            }
            System.out.println();
        }
    }
}

