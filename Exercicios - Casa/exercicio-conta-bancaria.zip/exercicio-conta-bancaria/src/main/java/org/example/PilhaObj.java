package org.example;

public class PilhaObj<T> {
    private int topo;
    private int capacidade;
    private T[] pilha;

    public PilhaObj(int capacidade) {
        this.topo = -1;
        this.capacidade = capacidade;
        this.pilha = (T[]) new Object[capacidade];
    }

    public boolean isEmpty() {
        return topo == -1;
    }

    public boolean isFull() {
        return topo == capacidade - 1;
    }

    public void push(T info) {
        if (!isFull()) {
            topo++;
            pilha[topo] = info;
        } else {
            throw new IllegalStateException("Pilha cheia!");
        }
    }

    public T peek() {
        if (!isEmpty()) {
            return pilha[topo];
        } else {
            throw new IllegalStateException("Pilha vazia!");
        }
    }

    public T pop() {
        if (!isEmpty()) {
            T valor = pilha[topo];
            topo--;
            return valor;
        } else {
            throw new IllegalStateException("Pilha vazia!");
        }
    }
}
