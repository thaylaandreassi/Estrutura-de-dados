package org.example;

public class ContaBancaria {

    private Integer numero;
    private Double saldo;

    // Construtor
    public ContaBancaria(Integer numero, Double saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }

    // Métodos

    public Boolean debitar(Double valor) {
        if (valor == null || valor <= 0) {
            throw new IllegalArgumentException("Valor inválido.");
        }

        if (saldo >= valor) {
            saldo -= valor;
            return true;
        }

        return false;
    }

    public void creditar(Double valor) {
        if (valor == null || valor <= 0) {
            throw new IllegalArgumentException("Valor inválido.");
        }

        saldo += valor;
    }

    @Override
    public String toString() {
        return "ContaBancaria [numero=" + numero + ", saldo=" + saldo + "]";
    }

    // Getters
    public Integer getNumero() {
        return numero;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }
}
